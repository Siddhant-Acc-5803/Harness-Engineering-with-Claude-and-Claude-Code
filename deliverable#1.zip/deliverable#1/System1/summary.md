# Run summary — 20261119_081249

- Model: `claude-haiku-4-5-20251001`
- Fixtures processed: 8
- Estimated total cost: **$0.1408** USD

| claim_id | outcome | claim_type | severity | turns | clarifications_asked | input_tokens | output_tokens | est_cost_usd | elapsed_s |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| claim_01_kitchen_fire | escalated |  | - | 3 | 0 | 9527 | 610 | 0.0126 | 6.9 |
| claim_02_stolen_bike | routed | theft | low | 5 | 0 | 17276 | 840 | 0.0215 | 9.3 |
| claim_03_water_damage | escalated |  | - | 5 | 1 | 16715 | 733 | 0.0204 | 9.4 |
| claim_04_neighbor_injury | routed | liability | high | 5 | 0 | 17375 | 850 | 0.0216 | 10.3 |
| claim_05_auto_collision | routed | auto | high | 4 | 0 | 15510 | 1045 | 0.0207 | 11.1 |
| claim_06_low_confidence_escalation | escalated |  | - | 2 | 0 | 6185 | 455 | 0.0085 | 5.6 |
| claim_07_tree_falls_on_car | escalated | auto | - | 3 | 0 | 10363 | 823 | 0.0145 | 9.3 |
| claim_08_minor_porch_damage | routed | property_damage | low | 5 | 0 | 17233 | 774 | 0.0211 | 9.1 |
