# Run summary — 20261119_061455

- Model: `claude-haiku-4-5-20251001`
- Fixtures processed: 8
- Estimated total cost: **$0.1253** USD

| claim_id | outcome | claim_type | severity | turns | clarifications_asked | input_tokens | output_tokens | est_cost_usd | elapsed_s |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| claim_01_kitchen_fire | escalated |  | - | 2 | 0 | 6269 | 426 | 0.0084 | 4.7 |
| claim_02_stolen_bike | escalated |  | - | 2 | 0 | 6051 | 381 | 0.008 | 4.1 |
| claim_03_water_damage | routed | property_damage | medium | 7 | 1 | 25857 | 1220 | 0.032 | 15.4 |
| claim_04_neighbor_injury | escalated |  | - | 2 | 0 | 6294 | 500 | 0.0088 | 5.5 |
| claim_05_auto_collision | routed | auto | high | 5 | 0 | 17902 | 933 | 0.0226 | 11.0 |
| claim_06_low_confidence_escalation | escalated |  | - | 3 | 0 | 9450 | 616 | 0.0125 | 7.5 |
| claim_07_tree_falls_on_car | escalated |  | - | 3 | 0 | 9275 | 494 | 0.0117 | 6.2 |
| claim_08_minor_porch_damage | routed | property_damage | low | 5 | 0 | 17325 | 805 | 0.0214 | 8.8 |
